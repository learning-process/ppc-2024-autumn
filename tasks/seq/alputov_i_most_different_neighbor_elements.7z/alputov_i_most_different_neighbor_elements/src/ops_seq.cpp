#include "seq/alputov_i_most_different_neighbor_elements/include/ops_seq.hpp"

#include <functional>
#include <random>
#include <thread>

using namespace std::chrono_literals;

bool alputov_i_most_different_neighbor_elements_seq::most_different_neighbor_elements_seq::pre_processing() {
  internal_order_test();

  std::vector<int> input = reinterpret_cast<std::vector<int>*>(taskData->inputs[0])[0];

  input_ = std::vector<int>(input.size() - 1);

  for (size_t i = 1; i < input.size(); ++i) {
    input_[i - 1] = std::abs(input[i] - input[i - 1]);
  }

  res = {input[0], 0};
  return true;
}

bool alputov_i_most_different_neighbor_elements_seq::most_different_neighbor_elements_seq::validation() {
  internal_order_test();
  return taskData->inputs_count[0] > 1 && taskData->outputs_count[0] == 2;
}

bool alputov_i_most_different_neighbor_elements_seq::most_different_neighbor_elements_seq::run() {
  internal_order_test();

  for (size_t i = 1; i < input_.size(); ++i) {
    if (res.first < input_[i]) res = {input_[i], i};
  }

  return true;
}

bool alputov_i_most_different_neighbor_elements_seq::most_different_neighbor_elements_seq::post_processing() {
  internal_order_test();
  reinterpret_cast<std::pair<int, int>*>(taskData->outputs[0])[0] = {input_[res.second], input_[res.second + 1]};
  return true;
}
